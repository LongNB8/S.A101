package fa.training.main;

import java.util.ArrayList;

import fa.training.entities.Car;
import fa.training.entities.Ford;
import fa.training.entities.Sedan;
import fa.training.entities.Truck;

public class MyOwnAutoShop {

	public static void main(String[] args) {
		ArrayList<Car> listCars = new ArrayList<Car>();
		Car sedan = new Sedan(300, 1000, "red", 10);
		Car ford1 = new Ford(500, 1500, "black", 1999, 10);
		Car ford2 = new Ford(600, 1700, "white", 1997, 5);
		Car truck1 = new Truck(250, 900, "yellow", 120);
		Car truck2 = new Truck(350, 1200, "blue", 100);

		listCars.add(sedan);
		listCars.add(ford1);
		listCars.add(ford2);
		listCars.add(truck1);
		listCars.add(truck2);

		for (Car car : listCars) {
			System.out.println(car.toString());
		}

	}

}
